#ifndef GENERALHEADER
#define GENERALHEADER

#include <QApplication>
#include <QMainWindow>
#include <QPushButton>
//#include <QUdpSocket>
#include <QDebug>
#include <QString>
#include <QObject>
#include <QThread>
#include <QFile>
#include <QFileDialog>
#include <QMessageBox>
#include <QXmlStreamReader>
#include <QtXmlPatterns/QXmlQuery>
#include <QStringList>
#include <QFileInfo>
//#include <QDomDocument>
#include <QVector>
#include <QDir>
#include <QMap>


#endif // GENERALHEADER

